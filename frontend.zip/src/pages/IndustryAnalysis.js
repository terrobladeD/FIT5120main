import React from 'react';
import { Container, Row, Col, Button } from 'react-bootstrap';

const IndustryAnalysis = () => {
  return (
    <Container>
      <Row>
        <Col>
          <p>This is the IndustryAnalysis page</p>
          <Button variant="primary">Get Started</Button>
        </Col>
      </Row>
    </Container>
  );
};

export default IndustryAnalysis;

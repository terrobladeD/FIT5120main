import React from 'react';

const Message = ({ message }) => {
  return <div>{message}</div>;
};

export default Message;